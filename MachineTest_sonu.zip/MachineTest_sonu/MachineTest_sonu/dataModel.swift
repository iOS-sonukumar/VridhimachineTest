//
//  empdetails.swift
//  MachineTest_sonu
//
//  Created by Sonu_Gupta on 04/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import Foundation

struct dataModel {
    var userId: String = ""
    var jobTitleName: String = ""
    var firstname: String = ""
    var lastname: String = ""
    var preferredFullName:  String = ""
    var employeeCode: String = ""
    var region: String = ""
    var phoneNumber: String = ""
    var emailAddress: String = ""
    
    
    init(userDetails: [String: Any]) {
        userId = userDetails["userId"] as? String ?? ""
        jobTitleName = userDetails["jobTitleName"] as? String ?? ""
        firstname = userDetails["firstName"] as? String ?? ""
        jobTitleName = userDetails["jobTitleName"] as? String ?? ""
        lastname = userDetails["lastName"] as? String ?? ""
        preferredFullName = userDetails["preferredFullName"] as? String ?? ""
        employeeCode = userDetails["employeeCode"] as? String ?? ""
        region = userDetails["region"] as? String ?? ""
        phoneNumber = userDetails["phoneNumber"] as? String ?? ""
        emailAddress = userDetails["emailAddress"] as? String ?? ""
             
    }
}
