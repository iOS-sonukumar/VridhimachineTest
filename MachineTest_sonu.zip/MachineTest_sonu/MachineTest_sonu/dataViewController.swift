//
//  ViewController.swift
//  MachineTest_sonu
//
//  Created by Sonu_Gupta on 04/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//



import UIKit

class dataViewController: UIViewController {
  
    @IBOutlet weak var tableView: UITableView!
    var userDetails: [dataModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchUserData()
        // Do any additional setup after loading the view.
    }
    
    // MARK: Private func
    private func fetchUserData() {
        let path = Bundle.main.path(forResource: "empdata", ofType: "json")
        let data = NSData(contentsOfFile: path ?? "") as Data?
        do {
            let json = try JSONSerialization.jsonObject(with: data!, options: []) as! [String: Any]
            if let aUserDetails = json["Employees"] as? [[String : Any]] {
                for element in aUserDetails {
                    userDetails += [dataModel(userDetails: element)]
                }
            }
        } catch let error as NSError {
            print("Failed to load: \(error.localizedDescription)")
        }
    }
}
extension dataViewController: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        userDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellTableViewCell", for: indexPath) as! cellTableViewCell
      
        cell.userIdLbl.text = "User Id - " + userDetails[indexPath.row].userId
        cell.jobTitleLbl.text = "Job Title - " + userDetails[indexPath.row].jobTitleName
        cell.firstnameLbl.text = "First Name - " + userDetails[indexPath.row].firstname
        cell.lastNameLbl.text = "Last Name - " + userDetails[indexPath.row].lastname
        cell.preferdProfileName.text = "Preferred Full Name - " + userDetails[indexPath.row].preferredFullName
        cell.employeecode.text = "Employee Code - " + userDetails[indexPath.row].employeeCode
        cell.phoneNumberLbl.text = "Region - " + userDetails[indexPath.row].region
        cell.regionLbl.text = "Phone Number - " + userDetails[indexPath.row].phoneNumber
        cell.emailIdLbl.text = "Email Address - " + userDetails[indexPath.row].emailAddress
      
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let home = self.storyboard?.instantiateViewController(withIdentifier: "employeeDetailsViewController") as! employeeDetailsViewController
        
        home.userId = "User Id - " + userDetails[indexPath.row].userId
        home.jobTitle = "Job Title - " + userDetails[indexPath.row].jobTitleName
         home.firstnam = "First Name - " + userDetails[indexPath.row].firstname
        home.lastName = "Last Name - " + userDetails[indexPath.row].lastname
        home.preferdProfile = "Preferred Full Name - " + userDetails[indexPath.row].preferredFullName
        home.empecode = "Employee Code - " +  userDetails[indexPath.row].employeeCode
        home.phoneNumber = "Phone Number - " +   userDetails[indexPath.row].phoneNumber
        home.region = "Region - " +  userDetails[indexPath.row].region
        home.emailId =  "Email Address - " +  userDetails[indexPath.row].emailAddress
        self.navigationController?.pushViewController(home, animated: false)
        
        }
    
}
