//
//  employeeDetailsViewController.swift
//  MachineTest_sonu
//
//  Created by admin on 04/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class employeeDetailsViewController: UIViewController {
    @IBOutlet weak var userIdLbl: UILabel!
    @IBOutlet weak var jobTitleLbl: UILabel!
    @IBOutlet weak var firstnameLbl: UILabel!
    @IBOutlet weak var lastNameLbl: UILabel!
    @IBOutlet weak var preferdProfileName: UILabel!
    @IBOutlet weak var employeecode: UILabel!
    @IBOutlet weak var phoneNumberLbl: UILabel!
    @IBOutlet weak var regionLbl: UILabel!
    @IBOutlet weak var emailIdLbl: UILabel!
    
    var userId = ""
    var jobTitle = ""
    var firstnam = ""
    var lastName = ""
     var preferdProfile = ""
     var empecode = ""
     var phoneNumber = ""
     var region = ""
    var emailId = ""
    
  
    override func viewDidLoad() {
        super.viewDidLoad()

        self.userIdLbl.text = userId
         self.jobTitleLbl.text = jobTitle
         self.firstnameLbl.text = firstnam
        self.lastNameLbl.text = lastName
         self.preferdProfileName.text = preferdProfile
         self.employeecode.text = empecode
         self.phoneNumberLbl.text = phoneNumber
         self.regionLbl.text = region
         self.emailIdLbl.text = emailId
        
        // Do any additional setup after loading the view.
    }
    

   
}
